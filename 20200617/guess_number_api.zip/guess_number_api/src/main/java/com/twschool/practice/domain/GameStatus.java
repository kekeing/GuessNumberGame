package com.twschool.practice.domain;

public enum GameStatus {
    CONTINUED, FAILED, SUCCEED
}
